import { readdir, readFile, writeFile, rename, rmdir } from 'node:fs/promises';
import path from 'node:path';
const root = path.resolve('dist');
async function walk(dir) {
 for (const entry of await readdir(dir,{withFileTypes:true})) {
  const file=path.join(dir,entry.name);
  if(entry.isDirectory()){await walk(file);await rmdir(file);}
  else if(dir!==root){
   const names=await readdir(root);
   if(names.includes(entry.name))throw new Error('Filename collision: '+entry.name);
   await rename(file,path.join(root,entry.name));
  }
 }
}
await walk(root);
const index=path.join(root,'index.html');
await writeFile(index,(await readFile(index,'utf8')).replaceAll('/leaf-showcase/assets/','/leaf-showcase/'));
await writeFile(path.join(root,'.nojekyll'),'');
