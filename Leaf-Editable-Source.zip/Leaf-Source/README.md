# Leaf — GitHub Pages edition

A greener Earth starts with a leaf.

Team Error 404 · Politeknik Besut Terengganu. Leaf remains a proposed concept.

Expected website address after Pages publication: https://firdauswarriors.github.io/leaf-showcase/

## Edit and build

Requires Node.js 22+ and pnpm 11.25.0.

```
pnpm install --frozen-lockfile --ignore-scripts
pnpm run dev
pnpm run build
```

This edition uses /leaf-showcase/ as its Vite base. The final build step flattens generated asset folders for GitHub's web uploader. Upload the contents of dist to the repository root, retain .nojekyll, and publish main / (root) in Settings → Pages.

The supplied public media and photos remain in normal folders while editing. src/assets.ts and scripts/flatten-pages.mjs prepare their flat publication paths. No server, account connection or environment secrets are required. The existing Sites edition is preserved separately.

See DESIGN.md, QA.md, DEPENDENCY-REVIEW.md and public/licenses for the reviewed material, content boundaries, motion and licensing details.
