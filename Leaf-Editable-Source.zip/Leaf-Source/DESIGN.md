# Leaf: light, clear, and grounded

## Context and review

React/TypeScript public hackathon showcase, viewed in Safari and on phones. Its job is to explain the proposed campus care journey and lead visitors to the PolyCC-owned proposal and slides. This is a website: Apple accessibility, hierarchy, material and interaction principles apply; native macOS menu bars and iOS tab-bar rules do not.

The requested `apple-design` skill was reviewed and installed from dickwu/apple-design-skill at `ff4ebddf0488598723a82bfdce1afb04de0b1c44`. No repo script was executed. Relevant references read: accessibility, layout, typography, color, designing-for-iOS/macOS, cross-platform, disclosure controls, motion and Liquid Glass. The source skill is personal local guidance and is not redistributed with this project.

### Critical / high findings

- The user reported upward jumps when changing questions. An initial locator-driven test also scrolled, but that tool centres controls, so its delta is not reliable proof of the site's own scroll. Source inspection found a page-wide ScrollTrigger refresh after disclosure resizing alongside native smooth scrolling. The controls also changed vertical position as exclusive panels collapsed. Fix: stable question selector/detail layout, no scroll mutation on selection, no global animation refresh during interaction, and explicit scrolling only on navigation links. `motion.md > Providing feedback`: “follows people’s gestures and expectations”.
- Automatic feature/journey scrolling removed the reader’s place. Fix: selections update the adjacent example; an explicit example link is available on phones. `accessibility.md > Cognitive`: “Keep actions simple and intuitive.”
- The old dark presentation and low-weight caption text conflicted with the newly requested light appearance. Fix: light opaque content surfaces, legible system body typography, green primary actions and clearer visual grouping. `layout.md > Visual hierarchy`: “Group related items”.

## Token plan before implementation

- Background #ffffff; grouped surface #f5f5f7; primary ink #1d1d1f; secondary #5f6368; Leaf action #24583e; soft botanical surface #eef4ee. Exact contrast ratios are recorded in the local review JSON.
- Display hierarchy: system UI 56–64px section headings, 32–48px compact; body 17–19px; UI 14–16px; secondary captions at least 13px in the website. A local serif stack is used for the Leaf wordmark only. No Apple font files are downloaded or embedded.
- Regular layout: left-aligned hero copy and CTA beside a framed botanical video; quieter paired content sections, stable interactive workbenches and a compact proposed-app demo.
- Compact layout: copy, media, content; native feature picker; compact journey choices above the example; all controls at least 44 CSS pixels where practical. No information depends on hover.
- Signature: the existing high-resolution botanical film becomes a framed living specimen on a white page. Leaf’s name, campus care records and exact tagline remain the focus.
- Motion: subtle hero drift, brief once-only entrances and feedback on changed examples. No content is permanently hidden. Native scrolling stays under the visitor’s control. Pause and reduced-motion still work.

Regular:
[ Leaf | sections | Read proposal ]
[ Leaf + exact tagline + CTA ][ framed botanical film ]
[ plant concerns ][ stable question choices + answer ]
[ illustrative record ][ Check / Understand / Follow up ]
[ feature choices ][ selected detail ]
[ care journey choices ][ illustrative example ]

Compact:
[ Leaf | proposal | menu ]
[ tagline, description, CTA ]
[ botanical film ]
[ concerns / choices / answer ]
[ feature picker / detail ]
[ compact journey choices / example ]

## Critique of the plan

A white page and system typography alone would be generic. The framed botanical specimen, exact Leaf tagline, PBT-001 illustrative care record and connected-care workflow give this page its subject. The original video remains untouched as content; it is not stretched behind readable copy or artificially recoloured. Glass is confined to floating navigation and media playback controls. Other cards are opaque. This deliberately light web appearance follows the user's request rather than adding an unrequested dark theme.

## 3.1 motion and material refinements

Below-fold blocks now enter with a short 3px phone / 6px desktop blur, 16px / 24px lift and 0→1 opacity, staggered at 65ms with a 195ms cap. After 720ms / 880ms all temporary styles clear. It happens once per motion session. Initial viewport content remains readable; keyboard focus finishes the relevant reveal immediately. Pause, reduced motion and print restore clear content. This uses IntersectionObserver plus GSAP, without page-wide layout refreshes or scroll mutation.

The reviewed rdev material is confined to the floating control layer. Its geometry stays fixed so links do not drift under the pointer. A frosted CSS fallback retains Safari readability. Studio refraction and Fresnel math are adapted for a single small capsule over the film, with the real playback button above it. Reading sections stay opaque. No full-screen graphics loop or editor is installed.

The film's first 1.25 seconds were quiet, while the old poster showed full bloom. The new palindrome starts at source frame 30, plays at twice the source rate, reaches bloom at about 2.4 seconds and returns without a hard stage cut. The poster comes from its first encoded frame. The film is still illustrative artwork.
