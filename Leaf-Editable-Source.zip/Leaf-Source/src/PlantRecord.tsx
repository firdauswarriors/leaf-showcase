import { Leaf, Camera, ClipboardCheck, BookOpen } from 'lucide-react';

export default function PlantRecord() {
  return <div className="record-card" aria-label="Illustrative shared plant profile">
    <header><span><Leaf size={19} />Shared plant record</span><span className="record-example">Illustrative</span></header>
    <div className="record-specimen"><svg viewBox="0 0 320 230" fill="none" aria-hidden="true"><path d="M157 212c4-42 10-100 1-158" stroke="#3c6d4c" strokeWidth="4" strokeLinecap="round" /><path d="M162 153c-42 9-75-10-87-44 39-10 75 2 87 44Z" fill="#8cae79" /><path d="M162 127c42 7 76-13 87-48-42-7-73 9-87 48Z" fill="#567f50" /><path d="M159 94c-29 0-51-18-54-44 29-2 50 17 54 44Z" fill="#b6cba0" /><path d="M161 69c-4-31 9-49 32-58 10 26-3 47-32 58Z" fill="#72985d" /><path d="M160 183c37 1 65-12 75-39-32-6-60 10-75 39Z" fill="#a1be8b" /><path d="m157 208 7-68m-3 12-60-32m62 4 62-31m-66 0-38-33m41 8 22-40m-25 154 54-26" stroke="#3c6d4c" strokeWidth="1.2" strokeLinecap="round" /></svg></div>
    <div className="record-title"><strong>PBT-001</strong><span>One plant. One place for its care.</span></div>
    <dl><div><dt>Plant identity</dt><dd>Species unconfirmed</dd></div><div><dt>Caretaker</dt><dd>To be assigned</dd></div></dl>
    <div className="record-connections"><span><Camera size={17} />Photo & context</span><span><ClipboardCheck size={17} />Care tasks</span><span><BookOpen size={17} />Follow-ups</span></div>
  </div>;
}
