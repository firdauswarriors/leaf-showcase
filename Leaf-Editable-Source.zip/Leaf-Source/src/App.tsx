import { asset } from './assets';
import GlassMaterial from './GlassMaterial';
import StudioGlass from './StudioGlass';
import { useEffect, useRef, useState } from 'react';
import type { KeyboardEvent } from 'react';
import gsap from 'gsap';
import { ArrowUpRight, ArrowDown, ArrowRight, Plus, Minus, Menu, X, Pause, Play, Leaf, Camera, ClipboardCheck, BookOpen, Users, Sprout, Check, ChevronRight } from 'lucide-react';
import BotanicalFilm from './BotanicalFilm';
import JourneyExplorer from './JourneyExplorer';
import { usePageMotion, useAnchorNavigation } from './usePageMotion';
import PlantRecord from './PlantRecord';
import { DOC, SLIDES, features, references } from './data';

const NAV_LINKS = [['The idea', '#problem'], ['Features', '#features'], ['The app', '#interface'], ['Way Forward', '#way-forward'], ['Our team', '#team']];
const SCREENS = ['Home', 'Plant check', 'Care results', 'Plant profile'];
const PROBLEMS = [
  ['What changed?', 'A visible symptom can have several explanations. Without watering, soil and light context, the next check can be unclear.', 'Capture the whole picture.', 'Photographs and care questions would give each concern a useful starting point.'],
  ['Who last cared for it?', 'Watering, photographs and actions may be scattered or go unrecorded. The next person starts without the history.', 'Keep one shared record.', 'A plant profile would connect caretakers, checks, completed tasks and dated observations.'],
  ['What happens next?', 'A report can stall when nobody owns the next action or knows when to return.', 'Give care an owner.', 'An assigned task and a follow-up date would turn a concern into a clear next step.'],
];

function LogoMark({ small = false }: { small?: boolean }) {
  return <span className={`logo-mark ${small ? 'small' : ''}`} aria-hidden="true"><Leaf size={small ? 21 : 28} strokeWidth={1.5} /></span>;
}
function useReducedMotion() {
  const [reduced, setReduced] = useState(() => matchMedia('(prefers-reduced-motion: reduce)').matches);
  useEffect(() => { const mq = matchMedia('(prefers-reduced-motion: reduce)'); const listener = () => setReduced(mq.matches); mq.addEventListener('change', listener); return () => mq.removeEventListener('change', listener); }, []);
  return reduced;
}
function ExternalLink({ href, children, className = '' }: { href: string; children: React.ReactNode; className?: string }) {
  return <a href={href} target="_blank" rel="noreferrer" className={className}>{children}<ArrowUpRight size={17} aria-hidden="true" /></a>;
}

function AppDemo() {
  const [screen, setScreen] = useState(0), [context, setContext] = useState(false), [review, setReview] = useState(false);
  const tabs = useRef<(HTMLButtonElement | null)[]>([]);
  function handleTabs(e: KeyboardEvent<HTMLButtonElement>) {
    if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(e.key)) return;
    e.preventDefault();
    const next = e.key === 'Home' ? 0 : e.key === 'End' ? 3 : (screen + (e.key === 'ArrowRight' ? 1 : 3)) % 4;
    setScreen(next); tabs.current[next]?.focus();
  }
  return <div className="app-explorer">
    <div className="app-copy">
      <div className="screen-tabs" role="tablist" aria-label="Illustrative Leaf screens">
        {SCREENS.map((name, i) => <button key={name} ref={el => { tabs.current[i] = el; }} id={`tab-${i}`} role="tab" aria-controls="app-panel" aria-selected={screen === i} tabIndex={screen === i ? 0 : -1} onClick={() => setScreen(i)} onKeyDown={handleTabs}><span>{name}</span><ChevronRight size={19} aria-hidden="true" /></button>)}
      </div>
      <div className="app-explanation" aria-live="polite">
        <h3>{['Start with the next action.', 'Good context comes first.', 'Guidance with clear limits.', 'A record that keeps growing.'][screen]}</h3>
        <p>{['See recent activity and begin a check from a simple campus home.', 'Capture the full plant and the affected area. Record care conditions before asking for guidance.', 'Separate visible observations from possible causes. Send uncertain cases to authorised staff.', 'Keep a caretaker, checks, tasks and dated observations connected to the same plant.'][screen]}</p>
        <p className="small-note">{screen === 1 ? 'Try adding care context in the screen.' : screen === 2 ? 'Try requesting a staff review.' : 'Select a screen to explore the concept.'}</p>
      </div>
    </div>
    <div className="phone-scene">
      <div className="phone" id="app-panel" role="tabpanel" aria-labelledby={`tab-${screen}`}>
        <div className="phone-status"><span>9:41</span><span className="phone-island" /><span>● ▰</span></div>
        <div className="phone-brand"><LogoMark small /><span>Leaf</span><span className="concept-badge">Concept</span></div>
        <div className="phone-content" key={screen}>
        {screen === 0 ? <>
          <p className="phone-eyebrow">Campus care, together</p><h3>Good care<br /><em>starts here.</em></h3>
          <div className="plant-drawing"><Sprout size={102} strokeWidth={0.8} aria-hidden="true" /><span>PBT-001 · example record</span></div>
          <button className="phone-primary" onClick={() => setScreen(1)}>New plant check <Plus size={17} /></button>
          <div className="task-preview"><span>Your next action · example</span><strong>Check soil moisture</strong><p>Caretaker to be assigned</p></div>
          <button className="phone-text-button" onClick={() => setScreen(3)}>View plant record <ArrowRight size={16} /></button>
        </> : screen === 1 ? <>
          <p className="phone-eyebrow">PBT-001 · example</p><h3>New plant<br /><em>check.</em></h3>
          <div className="photo-well"><Camera size={29} strokeWidth={1.3} /><strong>Full plant + affected area</strong><span>Photos would be added here.</span></div>
          <div className="phone-field"><span>Care context</span><strong>Water · soil · light · setting</strong></div>
          <button className="phone-outline" aria-expanded={context} onClick={() => setContext(!context)}>{context ? 'Hide example context' : 'Add care context'}{context ? <Minus size={16} /> : <Plus size={16} />}</button>
          {context && <p className="phone-note">Example: yellowing noticed this week. Soil moisture and drainage have not yet been checked.</p>}
          <button className="phone-primary" onClick={() => setScreen(2)}>Review example guidance <ArrowRight size={16} /></button>
        </> : screen === 2 ? <>
          <p className="phone-eyebrow">Illustrative · not a diagnosis</p><h3>Care<br /><em>results.</em></h3>
          <div className="result-line"><span>Visible observation</span><strong>Some leaves are yellowing.</strong></div>
          <div className="result-line"><span>Possible causes</span><strong>Watering or drainage.</strong><p>More context is needed.</p></div>
          <div className="result-line next-check"><span>Check next</span><strong>Soil moisture and standing water.</strong></div>
          <button className="phone-primary" aria-pressed={review} onClick={() => setReview(!review)}>{review ? 'Example review selected' : 'Request staff review'}{review ? <Check size={16} /> : <ArrowRight size={16} />}</button>
          <p className="phone-note" aria-live="polite">{review ? 'Demonstration only. No request has been sent.' : 'Proposed AI support needs feasibility testing and human review.'}</p>
        </> : <>
          <p className="phone-eyebrow">PBT-001 · example record</p><h3>Every plant,<br /><em>a story.</em></h3>
          <div className="profile-symbol"><Leaf size={49} strokeWidth={1} /></div>
          <div className="phone-field"><span>Plant identity</span><strong>Species to be confirmed</strong></div>
          <div className="phone-field"><span>Caretaker</span><strong>Assign a person or club</strong></div>
          <div className="journal-preview"><BookOpen size={19} /><div><span>Care journal</span><strong>A dated photo + observation</strong></div></div>
          <button className="phone-primary" onClick={() => setScreen(1)}>Start a plant check <Plus size={16} /></button>
        </>}
        </div>
        <div className="phone-home-indicator" aria-hidden="true" />
      </div>
      <p className="phone-caption">AppSheet-compatible interface concepts</p>
    </div>
  </div>;
}

export default function App() {
  const root = useRef<HTMLDivElement>(null), menuButton = useRef<HTMLButtonElement>(null);
  const reduced = useReducedMotion();
  const [paused, setPaused] = useState(false), [menu, setMenu] = useState(false), [scrolled, setScrolled] = useState(false);
  const [problem, setProblem] = useState(0), [selected, setSelected] = useState(0), [activeSection, setActiveSection] = useState('');
  usePageMotion(root, !reduced && !paused);
  useAnchorNavigation(root, !reduced && !paused);
  const FeatureIcon = [Sprout, Camera, Leaf, ClipboardCheck, BookOpen, Users, BookOpen][selected];
  useEffect(() => {
    document.documentElement.dataset.motion = reduced || paused ? 'off' : 'on';
    return () => { delete document.documentElement.dataset.motion; };
  }, [reduced, paused]);
  useEffect(() => {
    let frame = 0;
    const update = () => {
      frame = 0;
      const sections = [...document.querySelectorAll<HTMLElement>('main > section')];
      const current = sections.filter(section => section.getBoundingClientRect().top <= innerHeight * 0.35).at(-1)?.id || 'home';
      const map: Record<string, string> = { problem: '#problem', solution: '#problem', features: '#features', journey: '#features', interface: '#interface', ecosystem: '#interface', pilot: '#interface', 'way-forward': '#way-forward', team: '#team', proposal: '#team', references: '#team' };
      setActiveSection(map[current] || '');
    };
    const onScroll = () => { if (!frame) frame = requestAnimationFrame(update); };
    update(); window.addEventListener('scroll', onScroll, { passive: true }); window.addEventListener('resize', onScroll);
    return () => { cancelAnimationFrame(frame); window.removeEventListener('scroll', onScroll); window.removeEventListener('resize', onScroll); };
  }, []);
  useEffect(() => {
    const scroll = () => setScrolled(scrollY > 40); scroll();
    const key = (e: globalThis.KeyboardEvent) => { if (e.key === 'Escape') { setMenu(false); if (menu) menuButton.current?.focus(); } };
    window.addEventListener('scroll', scroll, { passive: true }); window.addEventListener('keydown', key);
    return () => { window.removeEventListener('scroll', scroll); window.removeEventListener('keydown', key); };
  }, [menu]);
  useEffect(() => {
    if (reduced) return;
    const ctx = gsap.context(() => {
      gsap.fromTo('.hero-title', { y: 12, opacity: .65 }, { y: 0, opacity: 1, duration: .65, ease: 'power3.out', clearProps: 'all' });
      gsap.fromTo('.hero-tagline', { y: 8, opacity: .65 }, { y: 0, opacity: 1, duration: .55, delay: .08, ease: 'power3.out', clearProps: 'all' });
    }, root);
    return () => ctx.revert();
  }, [reduced]);
  return <div ref={root} className="min-h-screen font-body site-root" data-motion={reduced || paused ? 'off' : 'on'}>
    <div className="reading-progress" aria-hidden="true"><span className="reading-progress-fill" /></div>
    <a className="skip-link" href="#main">Skip to content</a>
    <header className={`floating-header ${scrolled ? 'has-scrolled' : ''}`}>
      <div className="nav-shell liquid-glass rounded"><GlassMaterial />
        <a className="brand" href="#home" aria-label="Leaf home"><LogoMark /><span>Leaf</span></a>
        <nav className="desktop-nav" aria-label="Main navigation">{NAV_LINKS.map(([name, href]) => <a href={href} key={href} aria-current={activeSection === href ? 'location' : undefined}>{name}</a>)}</nav>
        <ExternalLink href={DOC} className="nav-cta">Read proposal</ExternalLink>
        <button ref={menuButton} className="mobile-menu-toggle" aria-expanded={menu} aria-controls="mobile-nav" aria-label={menu ? 'Close navigation' : 'Open navigation'} onClick={() => setMenu(!menu)}>{menu ? <X size={21} /> : <Menu size={21} />}</button>
      </div>
      {menu && <nav id="mobile-nav" className="mobile-nav liquid-glass-strong" aria-label="Mobile navigation"><GlassMaterial />{NAV_LINKS.map(([name, href]) => <a key={href} href={href} onClick={() => setMenu(false)}>{name}<ArrowUpRight size={18} /></a>)}<a href="#proposal" onClick={() => setMenu(false)}>Proposal & slides<ArrowUpRight size={18} /></a><a href="#references" onClick={() => setMenu(false)}>References<ArrowUpRight size={18} /></a></nav>}
    </header>
    <main id="main" tabIndex={-1}>
      <section className="hero" id="home" aria-label="Leaf introduction">
        <div className="hero-layout frame">
          <div className="hero-heading">
            <p className="hero-eyebrow"><span />A proposed campus plant-care assistant</p>
            <h1 className="hero-title">Leaf</h1>
            <p className="hero-tagline">A greener Earth starts with a leaf.</p>
            <p className="hero-description">A shared way to notice plant concerns, understand the context and follow through with care.</p>
            <div className="hero-actions"><a className="button button-primary" href="#problem">Explore Leaf <ArrowDown size={17} /></a><a className="button button-secondary" href="#interface">See the app concept <ArrowUpRight size={17} /></a></div>
            <p className="hero-credit">Team Error 404<span>Politeknik Besut Terengganu</span></p>
          </div>
          <figure className="hero-media">
            <div className="film-stage"><div className="hero-film-scroll"><BotanicalFilm paused={paused} reduced={reduced} /></div><button className="motion-button" disabled={reduced} onClick={() => setPaused(!paused)} aria-pressed={paused || reduced}><StudioGlass disabled={reduced} /><span className="motion-button-label">{paused || reduced ? <Play size={15} /> : <Pause size={15} />}{reduced ? 'Reduced motion' : paused ? 'Resume motion' : 'Pause motion'}</span></button></div>
            <figcaption><span>A living idea for shared greenery.</span><span>Illustrative artwork</span></figcaption>
          </figure>
        </div>
      </section>

      <section className="problem-section section-space" id="problem">
        <div className="section-grid frame">
          <div className="section-intro"><p className="eyebrow">The problem</p><h2>A concern needs<br /><em>more context.</em></h2><p className="lead">A yellow leaf can raise a question. Understanding what changed takes care history and someone to follow up.</p><p className="small-note">Campus challenges to validate through student and gardener interviews.</p></div>
          <div className="problem-explorer">
            <div className="problem-choices" role="group" aria-label="Choose a plant-care concern">{PROBLEMS.map(([question], i) => <button key={question} type="button" aria-pressed={problem === i} aria-controls="problem-detail" onClick={() => setProblem(i)}><span>{question}</span>{problem === i ? <Check size={20} aria-hidden="true" /> : <ChevronRight size={20} aria-hidden="true" />}</button>)}</div>
            <div id="problem-detail" className="problem-answer" aria-live="polite"><p className="problem-context">{PROBLEMS[problem][1]}</p><div className="proposed-fix"><span className="fix-symbol"><Leaf size={20} /></span><div><span className="fix-label">How Leaf would help</span><h3>{PROBLEMS[problem][2]}</h3><p>{PROBLEMS[problem][3]}</p></div></div></div>
          </div>
        </div>
      </section>

      <section className="solution-section" id="solution">
        <div className="solution-visual"><PlantRecord /></div>
        <div className="solution-copy"><p className="eyebrow">The proposed solution</p><h2>One plant.<br /><em>One shared story.</em></h2><p className="lead">Leaf would connect the people, context and actions around each plant.</p><ol className="care-steps">{[['Check', 'Capture photographs and care context.'], ['Understand', 'Review observations, possible causes and suggested checks.'], ['Follow up', 'Assign care, record action and return with a dated observation.']].map(([title, body], i) => <li key={title}><span>{i + 1}</span><div><h3>{title}</h3><p>{body}</p></div></li>)}</ol></div>
      </section>

      <section className="features-section section-space frame" id="features">
        <div className="section-heading"><div><p className="eyebrow">Core features</p><h2>Care, <em>connected.</em></h2></div><p className="lead">Seven proposed features.<br />One continuous care journey.</p></div>
        <div className="feature-explorer">
          <label className="feature-picker">Explore a feature<select aria-label="Explore a feature" value={selected} onChange={event => setSelected(Number(event.target.value))}>{features.map((feature, i) => <option value={i} key={feature.short}>{feature.short}</option>)}</select></label>
          <div className="feature-choices" aria-label="Explore proposed features">{features.map((feature, i) => <button key={feature.short} className={selected === i ? 'active' : ''} aria-pressed={selected === i} aria-controls="feature-detail" onClick={() => setSelected(i)}><span>{feature.short}</span><ArrowUpRight size={20} aria-hidden="true" /></button>)}</div>
          <div className="feature-panel" id="feature-detail" aria-live="polite">
            <div className="feature-emblem" key={`icon-${selected}`}><FeatureIcon strokeWidth={1.3} size={58} aria-hidden="true" /></div>
            <div className="feature-panel-copy" key={`copy-${selected}`}><span className="status-label">Proposed feature</span><h3>{features[selected].title}</h3><p>{features[selected].body}</p></div>
            <div className="record-links"><span><Sprout size={14} />Plant</span><span><Camera size={14} />Check</span><span><ClipboardCheck size={14} />Action</span><span><BookOpen size={14} />Journal</span></div>
          </div>
        </div>
      </section>

      <section className="journey-section section-space" id="journey"><div className="frame"><div className="section-heading"><div><p className="eyebrow">The user journey</p><h2>From a concern<br /><em>to a follow-up.</em></h2></div><p className="lead">A student notices yellowing leaves.<br />Here is how the proposed flow would help.</p></div>
        <JourneyExplorer />
        <p className="journey-note"><Users size={18} />If guidance is uncertain or the condition worsens, request authorised staff review.</p>
        <div className="user-roles"><h3>Shared greenery.<br /><em>Clear responsibility.</em></h3><dl>{[['Students', 'Report concerns and understand the next check.'], ['Environmental clubs', 'Maintain an assigned plant’s care history.'], ['Gardeners & staff', 'Review uncertain cases and approve maintenance work.'], ['Coordinators', 'Assign responsibility and track unresolved concerns.']].map(([name, text]) => <div key={name}><dt>{name}</dt><dd>{text}</dd></div>)}</dl></div>
      </div></section>

      <section className="interface-section section-space frame" id="interface"><div className="section-heading"><div><p className="eyebrow">Inside Leaf</p><h2>A calmer way<br /><em>to care.</em></h2></div><div><p className="lead">Explore the proposed interface.</p><p className="small-note">Illustrative screens. Leaf is a concept;<br />a working application has not been built.</p></div></div><AppDemo /></section>

      <section className="ecosystem-section section-space" id="ecosystem"><div className="frame"><div className="section-heading"><div><p className="eyebrow">The Google ecosystem</p><h2>A practical<br /><em>foundation.</em></h2></div><p className="lead">AppSheet is the application foundation.<br />Google Workspace for Education Plus is the intended institutional environment.</p></div>
        <div className="ecosystem-list">{[['AppSheet', 'The application', 'Forms, plant profiles, tasks, journals and staff review views.'], ['Google Sheets', 'The shared records', 'Linked plants, checks, tasks, journal entries, reports and users.'], ['Google Drive', 'The supporting material', 'Photographs and documents connected to each care record.']].map(([name, role, body]) => <article key={name}><h3>{name}</h3><span>{role}</span><p>{body}</p></article>)}</div>
        <div className="ai-roles"><h3>AI has two<br /><em>distinct roles.</em></h3><div><h4>Development support</h4><p>Gemini Apps can assist ideation and care-content drafts. People review the sources and guidance.</p><h4>Proposed in-app analysis</h4><p>A permitted photo-analysis connection must be tested first. Confirm the licence, administrator access, cost and organiser rules. Institutional access remains unconfirmed.</p><p className="small-note">Call a script requires Core or above. Extract AI is a separate capability requiring Enterprise Plus. <a href="#references">View platform references.</a></p></div></div>
      </div></section>

      <section className="pilot-section section-space frame" id="pilot"><div className="section-grid"><div><p className="eyebrow">The proposed campus pilot</p><h2>Start small.<br /><em>Learn carefully.</em></h2><p className="lead">Test whether people can understand their next action and keep a clearer care record.</p><div className="pilot-numbers"><div><strong>10</strong><span>registered plants</span></div><div><strong>5</strong><span>test users</span></div></div><p className="small-note">Proposed test sizes, not existing adoption.<br />Subject to permission, account access and a feasible prototype.</p></div><div className="pilot-measures"><h3>What we would measure</h3>{[['Reporting and review time', 'Time from submission to authorised review.'], ['Task completion', 'Completed tasks as a share of tasks due.'], ['Follow-up coverage', 'Plants with a dated follow-up check.'], ['User understanding', 'Can users explain their next action?']].map(([title, body]) => <div key={title}><h4>{title}</h4><p>{body}</p></div>)}<p className="small-note">Plant condition would be recorded as observations. Water use would be measured only with a consistent, feasible method.</p></div></div></section>

      <section className="roadmap-section section-space" id="way-forward"><div className="frame"><div className="section-heading"><div><p className="eyebrow">Way Forward</p><h2>Room <em>to grow.</em></h2></div><p className="lead">A proposed one-to-five-year direction.<br />Each stage depends on what the earlier work establishes.</p></div><div className="roadmap-growth-track" aria-hidden="true"><span className="roadmap-growth-fill" /><i /><i /><i /></div><div className="roadmap-grid">{[
        ['Year 1', 'Establish the roots.', 'Validate campus needs and account access. Test a permitted AI connection, build the core care journey and run a small approved pilot.', ['Plant profiles, checks and tasks', 'Care journal and staff review', 'Pilot, feedback and refinement']],
        ['Years 2–3', 'Strengthen the branches.', 'Extend the useful parts of the pilot into a more consistent campus care routine.', ['QR tags and searchable IDs', 'Watering logs and richer reports', 'English and Bahasa Melayu', 'Formal plant adoption by clubs']],
        ['Years 4–5', 'Explore a wider canopy.', 'Consider broader coverage once the workflow, resources and reviewed content can support it.', ['An authorised campus plant map', 'Broader plant coverage', 'Explore use at other institutions']],
      ].map(([year, title, body, items], index) => <article key={String(year)}><span className="year-label">{year}</span><h3>{title}</h3><p>{body}</p><ul>{(items as string[]).map(item => <li key={item}>{item}</li>)}</ul><details className="roadmap-requirements"><summary>Stage requirements<Plus size={16} aria-hidden="true" /></summary><p>{['Confirm campus permission, account access and a permitted AI connection before building and piloting.', 'Use pilot feedback to confirm a useful workflow, staff capacity and the resources for each extension.', 'Confirm reviewed content, resources, cost and permissions before exploring wider coverage.'][index]}</p></details></article>)}</div><p className="small-note roadmap-condition">Future plans depend on pilot findings, permission, cost, staff capacity and technical feasibility.</p></div></section>

      <section className="team-section section-space frame" id="team"><div className="section-heading"><div><p className="eyebrow">Team Error 404</p><h2>The people<br /><em>behind Leaf.</em></h2></div><p className="lead">Politeknik Besut Terengganu<br />A shared idea for thoughtful campus care.</p></div><div className="team-grid">{[['javin', 'Javin Raj Singh'], ['wen-an', 'Wen An A/L Kian Teck'], ['haikal', 'Mohamad Danish Haikal bin Mohd Aswari']].map(([file, name]) => <figure key={file}><div className="portrait"><img src={asset(`/images/${file}.webp`)} alt={name} loading="lazy" width="640" height="640" /></div><figcaption>{name}</figcaption></figure>)}</div><div className="supervisor"><span>Supervisor</span><strong>FIRDAUS BIN HASSAN</strong></div></section>

      <section className="proposal-section section-space" id="proposal"><div className="frame proposal-inner"><p className="eyebrow">Explore the complete idea</p><h2>A greener Earth<br /><em>starts with a leaf.</em></h2><p className="lead">Read our proposal. Explore the presentation.<br />Both are shared through our PolyCC-owned Google files.</p><div className="proposal-links"><ExternalLink href={DOC} className="button button-primary">Open Google Doc</ExternalLink><ExternalLink href={SLIDES} className="button button-secondary">Open Google Slides</ExternalLink></div></div></section>
      <section className="references-section frame" id="references"><details><summary><span>References & sources</span><Plus size={21} aria-hidden="true" /></summary><p className="reference-intro">Sources behind the competition context, plant-care caution and platform requirements.</p><ol>{references.map(ref => <li key={ref.url}><ExternalLink href={ref.url}>{ref.title}</ExternalLink><p>{ref.note}</p></li>)}</ol></details></section>
    </main>
    <footer className="site-footer frame"><a className="brand" href="#home"><LogoMark /><span>Leaf</span></a><p>Proposed concept by Error 404<br />MOHE Hackathon 2026</p><a href={asset("/credits.txt")} target="_blank" rel="noreferrer">Design & technology credits<ArrowUpRight size={14} /></a><a className="back-top" href="#home" aria-label="Back to top"><ArrowUpRight size={22} /></a></footer>
  </div>;
}
