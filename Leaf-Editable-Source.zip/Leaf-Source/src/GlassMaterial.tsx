import LiquidGlass from 'liquid-glass-react';

const REST = { x: 0, y: 0 };

/** Decorative material only: real links and buttons remain in the normal DOM. */
export default function GlassMaterial() {
  return <div className="leaf-glass-material" aria-hidden="true">
    <LiquidGlass className="leaf-glass-renderer" padding="0" overLight
      displacementScale={28} blurAmount={.32} saturation={125}
      aberrationIntensity={.45} elasticity={0} mode="standard"
      globalMousePos={REST} mouseOffset={REST}
      style={{ position: 'absolute', top: '0px', left: '0px', width: '100%', height: '100%' }}>
      <span />
    </LiquidGlass>
  </div>;
}
