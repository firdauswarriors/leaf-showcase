import { asset } from './assets';
import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';

/** A pre-rendered palindrome keeps original detail without a low-resolution canvas cache. */
export default function BotanicalFilm({ paused, reduced }: { paused: boolean; reduced: boolean }) {
  const videoRef = useRef<HTMLVideoElement>(null), videoBgRef = useRef<HTMLDivElement>(null);
  const active = useRef(true), pausedRef = useRef(paused);
  const [failed, setFailed] = useState(false), [ready, setReady] = useState(false);
  const [mobile, setMobile] = useState(() => matchMedia('(max-width: 767px)').matches);
  pausedRef.current = paused;
  useEffect(() => {
    const mq = matchMedia('(max-width: 767px)'), listener = () => setMobile(mq.matches);
    mq.addEventListener('change', listener); return () => mq.removeEventListener('change', listener);
  }, []);
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    setReady(false); setFailed(false);
    // Explicitly reload the responsive source; Safari can retain the old media resource.
    video.load();
  }, [mobile, reduced]);
  useEffect(() => {
    const video = videoRef.current, element = videoBgRef.current;
    if (!video || !element) return;
    const syncPlayback = () => {
      active.current = !document.hidden && element.getBoundingClientRect().bottom > 0 && element.getBoundingClientRect().top < innerHeight;
      if (!active.current || pausedRef.current || reduced) video.pause();
      else void video.play().catch(() => {});
    };
    const observer = new IntersectionObserver(syncPlayback, { threshold: 0 }); observer.observe(element);
    video.addEventListener('loadeddata', syncPlayback);
    document.addEventListener('visibilitychange', syncPlayback);
    syncPlayback();
    return () => { observer.disconnect(); video.pause(); video.removeEventListener('loadeddata', syncPlayback); document.removeEventListener('visibilitychange', syncPlayback); };
  }, [paused, reduced, mobile]);
  useEffect(() => {
    const target = videoBgRef.current;
    if (!target || reduced || paused || !matchMedia('(pointer: fine)').matches) return;
    let targetX = 0, targetY = 0, x = 0, y = 0;
    const onMove = (event: MouseEvent) => {
      targetX = ((event.clientX - innerWidth / 2) / (innerWidth / 2)) * 14;
      targetY = ((event.clientY - innerHeight / 2) / (innerHeight / 2)) * 14;
    };
    const tick = () => {
      if (!active.current) return;
      x += (targetX - x) * 0.06; y += (targetY - y) * 0.06;
      gsap.set(target, { x, y });
    };
    window.addEventListener('mousemove', onMove, { passive: true }); gsap.ticker.add(tick);
    return () => { window.removeEventListener('mousemove', onMove); gsap.ticker.remove(tick); gsap.set(target, { x: 0, y: 0 }); };
  }, [reduced, paused]);
  const source = asset(mobile ? '/media/leaf-growth-mobile.mp4' : '/media/leaf-growth-desktop.mp4');
  return <div ref={videoBgRef} className="film-background" aria-hidden="true" data-playback={reduced || failed ? 'still' : paused ? 'paused' : 'video-loop'} data-quality={mobile ? '1280' : '3328'}>
    <img className="film-poster" src={asset("/media/leaf-growth-poster.jpg")} alt="" fetchPriority="high" />
    <video ref={videoRef} src={reduced ? undefined : source} muted loop playsInline preload={reduced ? 'none' : 'auto'} poster={asset("/media/leaf-growth-poster.jpg")} className="film-video" onLoadedData={() => { setReady(true); setFailed(false); }} onError={() => setFailed(true)} style={{ display: reduced || failed ? 'none' : 'block', opacity: ready ? 1 : 0 }} />
  </div>;
}
