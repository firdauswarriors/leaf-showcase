/** GitHub Pages publishes this compact bundle at the repository root. */
export const asset = (path: string) => '/leaf-showcase/' + path.split('/').pop();
