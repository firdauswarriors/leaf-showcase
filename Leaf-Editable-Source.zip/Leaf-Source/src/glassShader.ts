/**
 * Refraction / dispersion / Fresnel edge adapted from Liquid Glass Studio.
 * Copyright (c) 2024 Charles Yin. MIT; see public/licenses/liquid-glass-studio.txt.
 * Source: iyinchao/liquid-glass-studio @ f7b28c36305a862f5cffed3ddd51511cf1204f56.
 * Leaf renders one small capsule, preserving native video and semantic controls.
 */
export const GLASS_VERTEX = `#version 300 es
in vec2 a_position;
out vec2 v_uv;
void main(){v_uv=(a_position+1.0)*.5;gl_Position=vec4(a_position,0.,1.);}`;

export const GLASS_FRAGMENT = `#version 300 es
precision highp float;
in vec2 v_uv;
uniform sampler2D u_bg;
uniform vec2 u_size;
uniform vec2 u_inset;
out vec4 fragColor;
float safeAsin(float x){return asin(clamp(x,-1.,1.));}
float shape(vec2 p){
  float r=u_size.y*.5-1.;
  vec2 q=abs(p)-u_size*.5+vec2(r+1.);
  return length(max(q,0.))+min(max(q.x,q.y),0.)-r;
}
void main(){
  vec2 p=(v_uv-.5)*u_size;
  float d=shape(p);
  if(d>1.){fragColor=vec4(0.);return;}
  float depth=max(0.,-d);
  vec2 normal=normalize(vec2(shape(p+vec2(.5,0.))-shape(p-vec2(.5,0.)),shape(p+vec2(0.,.5))-shape(p-vec2(0.,.5)))+vec2(.00001));
  float ratio=clamp(1.-depth/8.,0.,1.);
  float thetaI=safeAsin(ratio*ratio);
  float thetaT=safeAsin(sin(thetaI)/1.35);
  float edge=depth<8.?-tan(thetaT-thetaI):0.;
  vec2 offset=-normal*edge*5./(u_size+vec2(32.));
  vec2 uv=u_inset+v_uv*(1.-2.*u_inset);
  vec2 texel=1.1/(u_size+vec2(32.));
  vec3 center=(texture(u_bg,uv+offset).rgb*2.+texture(u_bg,uv+offset+texel).rgb+texture(u_bg,uv+offset-texel).rgb)*.25;
  center.r=mix(center.r,texture(u_bg,uv+offset*1.025).r,.4);
  center.b=mix(center.b,texture(u_bg,uv+offset*.975).b,.4);
  float fresnel=pow(clamp(1.-depth/7.,0.,1.),4.);
  float glare=pow(max(0.,dot(normal,normalize(vec2(-.6,.8)))),3.)*fresnel;
  vec3 color=mix(center,vec3(.97,.99,.97),.73);
  color=mix(color,vec3(1.),fresnel*.24+glare*.28);
  fragColor=vec4(color,1.-smoothstep(-.7,.7,d));
}`;
