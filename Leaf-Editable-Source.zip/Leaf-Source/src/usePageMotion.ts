import { useEffect } from 'react';
import type { RefObject } from 'react';
import gsap from 'gsap';

/** Motion changes paint properties only. Content updates never refresh or reposition the page. */
export function usePageMotion(root: RefObject<HTMLDivElement | null>, enabled: boolean) {
  useEffect(() => {
    const element = root.current;
    if (!element || !enabled) return;
    const film = element.querySelector<HTMLElement>('.hero-film-scroll');
    const hero = element.querySelector<HTMLElement>('.hero');
    const progress = element.querySelector<HTMLElement>('.reading-progress-fill');
    const roadmap = element.querySelector<HTMLElement>('.roadmap-grid');
    const growth = element.querySelector<HTMLElement>('.roadmap-growth-fill');
    const ctx = gsap.context(() => {}, element);
    const compact = matchMedia('(max-width: 767px)');
    const revealed = new WeakSet<Element>();
    const reveals = new Map<HTMLElement, gsap.core.Tween>();
    const selectors = [
      '.section-heading > *', '.section-intro > *', '.problem-choices button', '.problem-answer',
      '.solution-visual', '.solution-copy > .eyebrow', '.solution-copy > h2', '.solution-copy > .lead',
      '.care-steps li', '.feature-choices', '.feature-picker', '.feature-panel',
      '.journey-instruction', '.journey-grid', '.journey-detail', '.user-roles > *',
      '.screen-tabs', '.app-explanation', '.phone-scene', '.ecosystem-list article', '.ai-roles > *',
      '.pilot-section .section-grid > div:first-child > *', '.pilot-measures',
      '.roadmap-growth-track', '.roadmap-grid article', '.roadmap-condition',
      '.team-grid figure', '.supervisor', '.proposal-inner > *',
    ].join(',');
    const targets = [...element.querySelectorAll<HTMLElement>(selectors)].filter(node => {
      const box = node.getBoundingClientRect();
      return box.width > 0 && box.height > 0;
    });
    let frame = 0, alive = true;
    const update = () => {
      frame = 0;
      if (!alive) return;
      const pageRange = Math.max(1, document.documentElement.scrollHeight - innerHeight);
      if (progress) progress.style.transform = `scaleX(${Math.min(1, scrollY / pageRange)})`;
      if (film && hero) {
        const p = Math.max(0, Math.min(1, -hero.getBoundingClientRect().top / hero.offsetHeight));
        film.style.transform = `translate3d(0,${-16 * p}px,0) scale(${1 + 0.035 * p})`;
      }
      if (roadmap && growth) {
        const rect = roadmap.getBoundingClientRect();
        const p = Math.max(0, Math.min(1, (innerHeight * .85 - rect.top) / Math.max(1, rect.height + innerHeight * .2)));
        growth.style.transform = `scaleX(${p})`;
      }
    };
    const requestUpdate = () => { if (!frame) frame = requestAnimationFrame(update); };
    const finishReveal = (target: HTMLElement) => {
      reveals.get(target)?.progress(1);
      revealed.add(target);
      target.dataset.reveal = 'shown';
      gsap.set(target, { clearProps: 'transform,opacity,filter,willChange' });
    };
    const observer = new IntersectionObserver(entries => {
      const entering = entries.filter(entry => entry.isIntersecting && !revealed.has(entry.target));
      entering.forEach((entry, index) => {
        const target = entry.target as HTMLElement;
        observer.unobserve(target);
        revealed.add(target);
        target.dataset.reveal = 'revealing';
        ctx.add(() => {
          gsap.set(target, { y: compact.matches ? 16 : 24, filter: `blur(${compact.matches ? 3 : 6}px)` });
          const tween = gsap.to(target, {
            y: 0, opacity: 1, filter: 'blur(0px)',
            duration: compact.matches ? .72 : .88,
            delay: Math.min(index * .065, .195), ease: 'power2.out',
            onStart: () => { target.style.willChange = 'transform,opacity,filter'; },
            onComplete: () => { target.dataset.reveal = 'shown'; reveals.delete(target); },
            clearProps: 'transform,opacity,filter,willChange',
          });
          reveals.set(target, tween);
        });
      });
    }, { threshold: 0, rootMargin: '0px 0px -24px 0px' });
    ctx.add(() => {
      targets.forEach(target => {
        // Keep the initial viewport readable; progressively enhance content below it.
        if (target.getBoundingClientRect().top < innerHeight) {
          revealed.add(target); target.dataset.reveal = 'shown';
        } else {
          target.dataset.reveal = 'pending';
          gsap.set(target, { y: compact.matches ? 16 : 24, opacity: 0, filter: `blur(${compact.matches ? 3 : 6}px)` });
          observer.observe(target);
        }
      });
    });
    // Keyboard users can immediately read and operate any focused content.
    const onFocus = (event: FocusEvent) => {
      targets.filter(target => target.contains(event.target as Node)).forEach(target => {
        observer.unobserve(target); finishReveal(target);
      });
    };
    element.addEventListener('focusin', onFocus);
    window.addEventListener('scroll', requestUpdate, { passive: true });
    window.addEventListener('resize', requestUpdate);
    document.fonts.ready.then(() => { if (alive) requestUpdate(); });
    update();
    return () => {
      alive = false; cancelAnimationFrame(frame); observer.disconnect();
      window.removeEventListener('scroll', requestUpdate); window.removeEventListener('resize', requestUpdate);
      element.removeEventListener('focusin', onFocus);
      ctx.revert(); reveals.clear();
      targets.forEach(target => { delete target.dataset.reveal; });
      if (film) film.style.removeProperty('transform');
      if (progress) progress.style.removeProperty('transform');
      if (growth) growth.style.removeProperty('transform');
    };
  }, [root, enabled]);
}

/** Only an intentional navigation link scrolls. Selection buttons never change scroll position. */
export function useAnchorNavigation(root: RefObject<HTMLDivElement | null>, animate: boolean) {
  useEffect(() => {
    const element = root.current;
    if (!element) return;
    const navigate = (event: MouseEvent) => {
      if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
      const link = (event.target as Element).closest<HTMLAnchorElement>('a[href^="#"]');
      const hash = link?.getAttribute('href');
      const target = hash && hash.length > 1 ? document.getElementById(hash.slice(1)) : null;
      if (!target) return;
      event.preventDefault();
      // Updating the URL without native fragment navigation avoids Safari retargeting after layout changes.
      history.replaceState(null, '', hash);
      if (event.detail === 0) { target.tabIndex = -1; target.focus({ preventScroll: true }); }
      target.scrollIntoView({ block: 'start', behavior: animate ? 'smooth' : 'instant' });
    };
    element.addEventListener('click', navigate);
    return () => element.removeEventListener('click', navigate);
  }, [root, animate]);
}
