import { useEffect, useRef } from 'react';
import { GLASS_FRAGMENT, GLASS_VERTEX } from './glassShader';

/** Small video-backed glass control. The full-resolution film stays native. */
export default function StudioGlass({ disabled }: { disabled: boolean }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current;
    const video = canvas?.closest('.film-stage')?.querySelector('video');
    if (!canvas || !video || disabled || matchMedia('(prefers-reduced-transparency: reduce), (prefers-contrast: more)').matches) return;
    const gl = canvas.getContext('webgl2', { alpha: true, antialias: true, depth: false, powerPreference: 'low-power' });
    if (!gl) return;
    const feed = document.createElement('canvas');
    const ctx = feed.getContext('2d', { alpha: false });
    if (!ctx) return;
    const shaders: WebGLShader[] = [];
    const compile = (type: number, source: string) => {
      const shader = gl.createShader(type)!;
      shaders.push(shader); gl.shaderSource(shader, source); gl.compileShader(shader);
      return gl.getShaderParameter(shader, gl.COMPILE_STATUS) ? shader : null;
    };
    const vertex = compile(gl.VERTEX_SHADER, GLASS_VERTEX), fragment = compile(gl.FRAGMENT_SHADER, GLASS_FRAGMENT);
    if (!vertex || !fragment) { shaders.forEach(shader => gl.deleteShader(shader)); return; }
    const program = gl.createProgram()!;
    gl.attachShader(program, vertex); gl.attachShader(program, fragment); gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) { gl.deleteProgram(program); shaders.forEach(shader => gl.deleteShader(shader)); return; }
    const buffer = gl.createBuffer(), texture = gl.createTexture();
    gl.useProgram(program); gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1,-1,1,-1,-1,1,-1,1,1,-1,1,1]), gl.STATIC_DRAW);
    const position = gl.getAttribLocation(program, 'a_position');
    gl.enableVertexAttribArray(position); gl.vertexAttribPointer(position, 2, gl.FLOAT, false, 0, 0);
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
    const size = gl.getUniformLocation(program, 'u_size'), inset = gl.getUniformLocation(program, 'u_inset');
    let frame = 0, last = -1000, visible = true, alive = true;
    const draw = () => {
      if (!alive || !visible || document.hidden || video.readyState < 2 || !video.videoWidth) return;
      const box = canvas.getBoundingClientRect(), media = video.getBoundingClientRect();
      if (!box.width || !box.height || !media.width || !media.height) return;
      const dpr = Math.min(devicePixelRatio, 1.5), pad = 16;
      const w = Math.round(box.width * dpr), h = Math.round(box.height * dpr);
      if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; }
      const fw = Math.round((box.width + pad * 2) * dpr), fh = Math.round((box.height + pad * 2) * dpr);
      if (feed.width !== fw || feed.height !== fh) { feed.width = fw; feed.height = fh; }
      const scale = Math.max(media.width / video.videoWidth, media.height / video.videoHeight);
      const ox = media.left + (media.width - video.videoWidth * scale) / 2;
      const oy = media.top + (media.height - video.videoHeight * scale) / 2;
      try {
        ctx.drawImage(video, (box.left - pad - ox) / scale, (box.top - pad - oy) / scale,
          (box.width + pad * 2) / scale, (box.height + pad * 2) / scale, 0, 0, fw, fh);
        gl.viewport(0, 0, w, h); gl.useProgram(program); gl.bindTexture(gl.TEXTURE_2D, texture);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, feed);
        gl.uniform2f(size, box.width, box.height);
        gl.uniform2f(inset, pad / (box.width + pad * 2), pad / (box.height + pad * 2));
        gl.drawArrays(gl.TRIANGLES, 0, 6); canvas.dataset.glass = 'webgl2';
      } catch { delete canvas.dataset.glass; }
    };
    const tick = (now: number) => {
      frame = 0;
      if (!alive || !visible || document.hidden || video.paused) return;
      if (now - last >= 1000 / 24) { draw(); last = now; }
      frame = requestAnimationFrame(tick);
    };
    const sync = () => {
      cancelAnimationFrame(frame); frame = 0;
      draw();
      if (alive && visible && !document.hidden && !video.paused) frame = requestAnimationFrame(tick);
    };
    const observer = new IntersectionObserver(entries => { visible = entries[0].isIntersecting; sync(); });
    observer.observe(canvas);
    const resize = new ResizeObserver(sync); resize.observe(canvas);
    const lost = () => { cancelAnimationFrame(frame); delete canvas.dataset.glass; };
    canvas.addEventListener('webglcontextlost', lost);
    ['play', 'pause', 'loadeddata', 'seeked'].forEach(event => video.addEventListener(event, sync));
    document.addEventListener('visibilitychange', sync); window.addEventListener('resize', sync); sync();
    return () => {
      alive = false; cancelAnimationFrame(frame); observer.disconnect(); resize.disconnect();
      canvas.removeEventListener('webglcontextlost', lost);
      ['play', 'pause', 'loadeddata', 'seeked'].forEach(event => video.removeEventListener(event, sync));
      document.removeEventListener('visibilitychange', sync); window.removeEventListener('resize', sync);
      gl.deleteTexture(texture); gl.deleteBuffer(buffer); gl.deleteProgram(program); shaders.forEach(shader => gl.deleteShader(shader));
      delete canvas.dataset.glass;
    };
  }, [disabled]);
  return <canvas ref={ref} className="studio-glass-canvas" aria-hidden="true" />;
}
