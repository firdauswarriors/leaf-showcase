import { useRef, useState } from 'react';
import type { KeyboardEvent } from 'react';
import { ArrowRight, ArrowLeft, Leaf, Camera, BookOpen, ClipboardCheck, Users, Search } from 'lucide-react';

const STEPS = [
  { title: 'Find the plant', short: 'Plant record', body: 'Open the profile by list or plant ID. QR tags are a future extension.', detail: 'Open PBT-001. Its identity, location and caretaker would sit together, with any earlier checks and care tasks.', record: 'Plant ID: PBT-001 · species to be confirmed', Icon: Search },
  { title: 'Add the context', short: 'Photo & context', body: 'Photograph the plant and affected area, then answer care questions.', detail: 'Add a whole-plant photo and a close-up of the yellowing leaves. Record what is known about watering, soil, light and when the change began.', record: 'Photographs + care questions', Icon: Camera },
  { title: 'Review guidance', short: 'Care guidance', body: 'Read visible observations, possible causes and suggested checks.', detail: 'Keep the visible observation, “some leaves are yellowing”, separate from possible causes. Soil moisture and standing water are example next checks.', record: 'Illustrative guidance · not a diagnosis', Icon: Leaf },
  { title: 'Choose an action', short: 'Next action', body: 'Record a next step or request an authorised gardener’s review.', detail: 'Choose a suitable check or ask authorised staff to review an uncertain concern. Maintenance work would follow the institution’s approval process.', record: 'Next action or staff review', Icon: ClipboardCheck },
  { title: 'Give care an owner', short: 'Assigned care', body: 'Assign the task. The caretaker records the action and status.', detail: 'Link a caretaker and due date to the task. When the check is done, the caretaker would record what they observed and what action they took.', record: 'Caretaker + due date + status', Icon: Users },
  { title: 'Return and compare', short: 'Care journal', body: 'Add a dated photograph and observation to the care journal.', detail: 'Return with another photograph and a dated observation. The record would show what changed; it would not assume that a plant recovered.', record: 'Dated follow-up · observed condition', Icon: BookOpen },
];

export default function JourneyExplorer() {
  const [step, setStep] = useState(0);
  const controls = useRef<(HTMLButtonElement | null)[]>([]);
  const current = STEPS[step];
  const Icon = current.Icon;
  function handleKey(event: KeyboardEvent<HTMLButtonElement>, index: number) {
    if (!['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Home', 'End'].includes(event.key)) return;
    event.preventDefault();
    const next = event.key === 'Home' ? 0 : event.key === 'End' ? 5 : (index + (event.key === 'ArrowRight' || event.key === 'ArrowDown' ? 1 : 5)) % 6;
    setStep(next); controls.current[next]?.focus();
  }
  return <div className="journey-explorer">
    <div className="journey-instruction"><p>Choose a step to follow one illustrative concern.</p><a href="#journey-detail">View selected example <ArrowRight size={15} /></a></div><div className="journey-workbench">
    <ol className="journey-grid">{STEPS.map((item, i) => <li key={item.title} className={step === i ? 'is-selected' : ''}>
      <button className="journey-select" ref={el => { controls.current[i] = el; }} aria-pressed={step === i} aria-controls="journey-detail" onClick={() => setStep(i)} onKeyDown={event => handleKey(event, i)} aria-label={`Step ${i + 1}: ${item.title}`}>
        <span className="journey-number">0{i + 1}<ArrowRight size={19} aria-hidden="true" /></span>
        <span className="journey-title">{item.title}</span><span className="journey-summary">{item.body}</span>
      </button>
    </li>)}</ol>
    <div className="journey-detail" id="journey-detail">
      <div className="journey-plant-record"><span className="journey-record-label">Illustrative plant record</span><strong>PBT-001</strong><div className="journey-symbol" key={step}><Icon size={62} strokeWidth={1} aria-hidden="true" /></div><span>{current.short}</span></div>
      <div className="journey-detail-copy" aria-live="polite"><span className="journey-position">Step {step + 1} of 6</span><h3>{current.title}</h3><p>{current.detail}</p><span className="journey-record-type">{current.record}</span></div>
      <div className="journey-step-controls"><button onClick={() => setStep(step - 1)} disabled={step === 0} aria-label="Previous journey step"><ArrowLeft size={18} /></button><button onClick={() => setStep(step === 5 ? 0 : step + 1)} className="journey-next">{step === 5 ? 'Start again' : 'Next step'}<ArrowRight size={17} /></button></div>
      <div className="journey-step-track" aria-hidden="true"><span style={{ transform: `scaleX(${(step + 1) / 6})` }} /></div>
    </div></div>
  </div>;
}
