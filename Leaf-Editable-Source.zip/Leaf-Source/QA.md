# Leaf 3.0 — light redesign verification

Checked 30 October 2026, Malaysia date. Tests used the production Vite build, the supported CUA browser controls and native Safari.

## Build and dependencies

- Strict TypeScript and production build pass. Approximately 337 kB JS (110 kB gzip), 49.5 kB CSS (10.7 kB gzip). The existing Lucide `use client` bundler advisory remains harmless in this client-only Vite project.
- No application dependency was added. Fresh `pnpm audit --json`: 122 resolved dependencies, zero known advisories. Exact pins and lockfile retained; see DEPENDENCY-REVIEW.md for the scope and limits of this check.
- The requested Apple design skill was reviewed at ff4ebddf0488598723a82bfdce1afb04de0b1c44 and installed locally. No repository script ran; no skill files are bundled with the website.

## Interaction regression

- The three questions now share a stable selection/detail layout. Real pointer tests at desktop scrollY 655 and phone scrollY 957.5 kept exactly the same scrollY after changing questions. Native Safari also switched both other questions without changing the scrollbar or moving the controls.
- The initial baseline locator-driven test moved 133px, but the tool centres elements; that number cannot establish the old site's native scroll delta. Final regression measurements use raw pointer clicks. The old page-wide animation refresh on disclosure resize and automatic selection scrolling were removed.
- All seven desktop feature controls and all seven phone picker options displayed the correct title. Exactly one icon and one copy block remained after each change. Distinct sibling keys fix the stale-icon accumulation found during testing. Phone picker selections kept scrollY 3380 for all seven choices.
- Journey keyboard End selected step 6 and moved focus to its control. Start again returned to step 1. Selection, next/previous and explicit View selected example navigation remain separate; selection does not scroll.
- Four app tabs each display exactly one screen. The staff-review example toggled its selected state without sending a request. These remain illustrative interfaces.
- All three Stage requirements disclosures opened independently. References opens and contains five source entries. Proposal CTA URLs match the existing PolyCC Google Doc and Slides links.
- Pointer and keyboard anchor navigation reached the intended sections. Keyboard focus is assigned before scrolling, avoiding Safari cancellation. Navigation alone scrolls; selections do not rewrite the hash.
- Pause motion set data-motion off and paused the video. Resume restored motion. All baseline content remains readable before entrance animation.
- The browser console returned no errors or warnings during the final checked session.

## Visual and responsive review

- Reviewed desktop 1440×960, phone 390×844, narrow phone 320×640 and tablet 768×900. Zero document horizontal overflow at each size. Full-page contact sheets were inspected for all content sections. Team images loaded with all three correct names and matched crops.
- Native Safari local production preview rendered the light hero, navigation and question section. The question selector remained in place while its answer changed. The temporary Safari QA tab was closed afterward.
- Light opaque surfaces, dark text, restrained green actions, system typography, a framed botanical film and an original illustrative plant-record SVG replace the dark visual system. Tablet roadmap cards stack to preserve readable copy. Phones use a native feature picker and compact six-step journey choices.
- Core text token contrast on white: #1d1d1f 16.83:1; #5f6368 6.05:1; #24583e 8.27:1. System fonts require no external font requests. Focus indicators remain on controls; programmatic section targets do not draw a page-sized outline.
- Native video sources retain 3328×2492 desktop and 1280×958 phone dimensions, with the existing 12-second forward/reverse loop and local full-resolution poster. No canvas frame cache. Desktop/phone source swapping explicitly reloads for Safari compatibility.

## Limits

OS-level reduced-motion mode, screen readers, physical phone hardware and browser zoom at 200% were not directly exercised. Reduced-motion and failed-video poster fallbacks were reviewed in source. Viewport tests do not establish a full accessibility certification. No pilot results, adoption, diagnosis accuracy or finished application functionality are claimed. Exact tagline, team information, references and existing Google file URLs are retained.

## 3.1 scroll reveals, growth timing and glass

The checks above describe 3.0. This update adds:

- Strict production build and TypeScript pass. New JS ~397 kB / 145 kB gzip; CSS ~51.8 kB / 11.2 kB gzip. Fresh audit: zero known advisories, 123 resolved dependencies.
- Browser samples during real smooth navigation recorded blur decreasing from 6px to 2.03px while opacity rose from 0 to 0.662. At rest the visible roadmap targets all reported filter none, opacity 1 and phase shown. Temporary will-change is cleared after reveal.
- Pause motion removed every pending reveal and paused the video. Motion cleanup does not refresh page geometry or scroll.
- Desktop browser loaded the new 3328px video, duration 4.75s. Phone source swap reached 1280px / 4.75s. Both encoded files probe to 114 frames at 24fps. Poster generated directly from encoded frame 0. First 1.25s of the source is omitted, and playback is doubled; bloom arrives by approximately 2.4s.
- WebGL2 playback material reported ready in desktop and phone browser previews. Console returned no warnings or errors during the checked interactions. Navigation uses exactly one rdev material instance, with a second only while the mobile menu is open. Real links and buttons remain semantic DOM controls.
- Phone menu visually reviewed over the moving film: frosted background, readable dark labels and clear separated targets. At 390px the document has no horizontal overflow.

Upstream licences are preserved. OS preference modes and physical hardware performance remain subject to the limits described above.

Final 3.1 regression: at phone scrollY 957.5, all three question changes kept exactly the same scrollY. At 320px the document has zero horizontal overflow. The updated glass was checked in the supported browser preview; a separate native Safari check could not be completed while another foreground video surface was active. Safari's navigation fallback is implemented from the library's documented limitation; the earlier 3.0 Safari results above do not certify this new shader update.
