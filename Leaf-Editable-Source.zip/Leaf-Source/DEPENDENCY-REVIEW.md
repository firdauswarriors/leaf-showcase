# Leaf redesign dependency review

Reviewed 30 October 2026 (user's Malaysia date). Registry metadata was checked for package identity, upstream repository, licence, dependencies and install hooks before adding packages. Versions are exact pins; pnpm lockfile records the resolved tree and integrity hashes. Installs were run with lifecycle scripts disabled. No application dependency, MCP server, account connection or UI library was added for the light redesign. The requested Apple design skill was reviewed and installed as local Markdown guidance; its optional repository script was not executed.

## Runtime

- React / React DOM 19.3.1 — existing exact pins, official React packages, MIT.
- GSAP 3.15.0 — existing exact pin, official GSAP package, Standard GSAP License.
- lucide-react 1.64.0 — official lucide-icons/lucide repository, ISC, no runtime dependencies or install hooks. Only explicitly imported icons ship. pnpm recorded a narrow release-age exception for this reviewed exact version.

## Build tools

- Vite 8.3.5 — existing exact pin, official vitejs/vite, MIT.
- TypeScript 6.0.2 — official microsoft/TypeScript, Apache-2.0; no runtime dependencies/install hooks. Selected the established JS compiler release instead of introducing the newer native 7.x toolchain.
- Tailwind CSS 3.4.19 — official tailwindlabs/tailwindcss v3, MIT. Uses the template's requested @tailwind directives/config format. Its published scripts are author build/test/publish commands, not install lifecycle hooks.
- PostCSS 8.5.32, Autoprefixer 10.6.2 — official postcss packages, MIT, no install hooks.
- @types/react / @types/react-dom 19.3.0 — official DefinitelyTyped packages, MIT, development types only.

## Audit and scope

`pnpm audit --json`: 122 total resolved dependencies, **0 known advisories** across info/low/moderate/high/critical. This is a registry advisory check, not a guarantee that all code is secure. No lifecycle hooks were enabled. No remote code from the supplied video or font URLs is executed.

Removed previous `three`, `@gsap/react`, `@fontsource/dm-sans` and `@fontsource/instrument-serif` dependencies. No ThreeUI or other UI framework is included in this version.

## Assets and external requests

The user-provided CloudFront MP4 returned 200, 3328×2492, 6.04 seconds, approximately 18.2 MB. It was inspected visually. The current desktop loop retains 3328×2492, 24fps, 12 seconds, approximately 23.65 MB. Phones receive a 1280×958 loop of approximately 4.27 MB. Reverse playback is pre-rendered offline; the browser uses native video rather than an in-memory canvas frame cache. A local poster prevents empty/error states. Video and photographs are served from this Site, avoiding a third-party video request at runtime.

The light redesign uses local system UI and serif font stacks. External Google Fonts imports and the broken, unused Dirtyline declaration were removed. No font network request is needed.

Official implementation references:
- https://v3.tailwindcss.com/docs/guides/vite
- https://lucide.dev/guide/react
- https://developer.mozilla.org/en-US/docs/Web/API/HTMLVideoElement/requestVideoFrameCallback

## 3.1 requested Liquid Glass integration

- Added exact `liquid-glass-react@1.1.1` from npm with lifecycle scripts disabled. Registry tarball inspected before installation (11 files, 180,339 unpacked bytes; SHA-1 d510517b5fda7785890e28a7885881abff887421; integrity pinned in pnpm lock). No runtime dependencies beyond React/React DOM peers; existing React 19 meets them. No install lifecycle hooks; its prepublishOnly author build was not executed.
- Reviewed its published JS: inline displacement-map images, SVG filters, React DOM event/state logic, optional canvas shader-map generation. No network requests, credential access, persistence or dynamic evaluation found in reviewed runtime. Use standard mode, fixed geometry and no mouse listeners to limit cost. Upstream checkout ac48eab18d1f7f444ae30002d240cae29c863a21; published package gitHead 2f134d928b0313a7075f22e9f844212a72254231. MIT notice retained at public/licenses/liquid-glass-react.txt.
- Reviewed Liquid Glass Studio at f7b28c36305a862f5cffed3ddd51511cf1204f56. It is a full private demo app with MUI, Leva and an editor; those dependencies were not installed. Downloaded/reviewed LICENSE and shader/math/SDF source. Adapted only bounded refraction, dispersion and Fresnel math into Leaf's own small WebGL2 control. No upstream scripts executed. MIT notice retained at public/licenses/liquid-glass-studio.txt.
- Fresh advisory audit after installation: 123 total resolved dependencies, zero known advisories. This is not a comprehensive security guarantee.
- The library documents partial Safari/Firefox displacement support. Leaf keeps a readable frosted fallback for navigation; the Studio-derived WebGL control has a CSS fallback for unavailable/lost graphics contexts.
- New local video loop: 4.75 seconds, 114 frames, 24fps; desktop 3328×2492 / 11,750,695 bytes, phone 1280×958 / 2,123,576 bytes. Opening poster derives from the encoded first frame. Replaced prior generated video files; previous source history and the prior project bundle retain them.
